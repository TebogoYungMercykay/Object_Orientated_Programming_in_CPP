#ifndef INVENTORY_H
#define INVENTORY_H

#include <iostream>
#include <string>

using namespace std;

template <typename T = string>// NOTE: "class" and "typename" are synonyms, 
							// either can be used to create templates
class Inventory {
 public:
	  Inventory(int = 10);
	  virtual ~Inventory(); // The destructor is virtual, since we plan to inherit

	  T * inspectItem(int i); // Get a pointer to a dynamic object at index i
	  T * getLastItem(); // Get the last item added to the inventory
	  void addItem(T * ); // Add a dynamic object to the inventory
 
	  int getNumItems() const; // Get the current total number of items
	  bool isEmpty() const; // Check if the inventory is empty
 
 protected:
	  T* * inventory; // 1D array of dynamic objects
	  int size;
	  int numItems;
};

#include "Inventory.cpp" // We are using Option 2: Include .cpp in .h

#endif
