#ifndef Searchable_INVENTORY_CPP
#define Searchable_INVENTORY_CPP

template <typename T>
int SearchableInventory<T>::findItem(T * item)
{
	for(int i = 0; i < this->numItems; i++) {
		
		if(item == this->inventory[i]) // compare addresses
			return i;
	}
	
	throw "Item not found";
}

#endif