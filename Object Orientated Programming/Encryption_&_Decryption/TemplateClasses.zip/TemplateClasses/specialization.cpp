// template specialization
#include <iostream>
using namespace std;

// class template:
template <class MyCont> // NOTE: You can call your template type anything,
					     // it does not have to be "T".
class mycontainer {
    MyCont element;
  public:
    mycontainer (MyCont arg) {element=arg;}
    MyCont increase () { return ++element; }
    MyCont get () {return element; }
};

// class template specialization:
template <>
class mycontainer <char> {
    char element;
  public:
    mycontainer (char arg) {element=arg;}
    
    char increase () {return ++element;}
    char get () {return element;}    
    
    char uppercase ()
    {
      if ((element>='a')&&(element<='z'))
      element += 'A'-'a';
      return element;
    }
    
    char lowercase ()
    {
      if ((element>='A')&&(element<='Z'))
      element -= 'A'-'a';
      return element;
    }
};

int main () {
  mycontainer<int> myint (7);
	
  mycontainer<char> mychar ('j');
	
  cout << myint.get() << endl;
  cout << myint.increase() << endl;
  //cout << myint.uppercase() << endl;
	
	
  cout << mychar.get() << endl;
  cout << mychar.uppercase() << endl;
  cout << mychar.increase() << endl;
  cout << mychar.lowercase() << endl;
  return 0;
}