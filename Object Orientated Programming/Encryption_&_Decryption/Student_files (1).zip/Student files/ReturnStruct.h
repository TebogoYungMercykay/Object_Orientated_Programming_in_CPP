#ifndef RETURN_STRUCT_H
#define RETURN_STRUCT_H

struct ReturnStruct
{
    public:
        int arraySize;
        unsigned char * returnArray;
};

#endif