#include "UnderflowException.h"

void UnderflowException::printMessage()
{
    std::cout << "underflow exception occured";
    std::cout<<"\n";
}
