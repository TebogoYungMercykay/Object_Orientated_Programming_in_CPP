#include "RotateException.h"

void RotateException::printMessage()
{
    std::cout<<"rotation exception occured";
    std::cout<<std::endl;
}
