#include "OverflowException.h"

void OverflowException::printMessage()
{
    std::cout << "overflow exception occured";
    std::cout<<"\n";
}
