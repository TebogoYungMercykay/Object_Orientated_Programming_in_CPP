#ifndef BabushkaException_H
#define BabushkaException_H
#include <iostream>

class BabushkaException
{
    public:
        virtual void printMessage()=0;
};
#endif