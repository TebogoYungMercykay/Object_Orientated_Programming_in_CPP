#include "DisplacementException.h"

void DisplacementException::printMessage()
{
    std::cout << "displacement exception occured";
    std::cout<<"\n";
}
